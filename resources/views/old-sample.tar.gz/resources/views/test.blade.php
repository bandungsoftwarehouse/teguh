<?php use App\Http\Controllers\FilesController ?>
<html>
<head>
</head>
<body>
<object width="590" height="90">
    <param name="movie" value="{{ FilesController::getPath('car.swf') }}">
    <embed src="{{ FilesController::getPath('car.swf') }}" width="590" height="90">
    </embed>
</object>
<form class="" action="/logout" method="post">
  {{ csrf_field() }}
  <button type="submit" name="logout">Logout</button>
</form>
{{ FilesController::getPath('car.swf') }}
</body>
</html>
